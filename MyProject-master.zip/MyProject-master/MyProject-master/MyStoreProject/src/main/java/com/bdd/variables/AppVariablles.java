package com.bdd.variables;
/**
 * This Class contains all the variables related to the application which as used globally
 * 
 * 
 */
public class AppVariablles {

}
